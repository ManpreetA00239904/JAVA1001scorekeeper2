package com.example.manpreet;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    String names1[]={"india","bangladesh","nepal","russia"};
    String names2[]={"us","uk","canada","aus"};
    String points[]={"1","2","3","4"};
    Spinner spteam1 , spteam2 ,sppoints;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spteam1 = (Spinner) (findViewById(R.id.spteam1));
        final ArrayAdapter<String> adteam1 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names1);
        spteam1.setAdapter(adteam1);

        spteam2 = (Spinner) (findViewById(R.id.spteam2));
        final ArrayAdapter<String> adteam2 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names2);
        spteam2.setAdapter(adteam2);

        sppoints = (Spinner) (findViewById(R.id.sppoints));
        final ArrayAdapter<String> adpoints = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,points);
        sppoints.setAdapter(adpoints);

    }
}
