package com.example.manpreet;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    //three array to store country names and points
    String names1[]={"india","bangladesh","nepal","russia"};
    String names2[]={"us","uk","canada","aus"};
    String points[]={"1","2","3","4"};
    Spinner spteam1 , spteam2 ,sppoints;
    Button btteam1increase ,btteam1decrease ,btteam2increase , btteam2decrease ;
    TextView tvscore1 , tvscore2 ;
    int team1score =0 , team2score =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btteam1increase = (Button) (findViewById(R.id.btteam1increase));
        btteam1decrease = (Button) (findViewById(R.id.btteam1decrease));
        btteam2increase = (Button) (findViewById(R.id.btteam2increase));
        btteam2decrease = (Button) (findViewById(R.id.btteam2decrease));
        tvscore1 = (TextView) (findViewById(R.id.tvscore1));
        tvscore2 = (TextView) (findViewById(R.id.tvscore2));
        spteam1 = (Spinner) (findViewById(R.id.spteam1));
        spteam2 = (Spinner) (findViewById(R.id.spteam2));
        sppoints = (Spinner) (findViewById(R.id.sppoints));

        final ArrayAdapter<String> adteam1 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names1);
        spteam1.setAdapter(adteam1);//team 1 spinner
        final ArrayAdapter<String> adteam2 = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names2);
        spteam2.setAdapter(adteam2);// team 2 spinner
        final ArrayAdapter<String> adpoints = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,points);
        sppoints.setAdapter(adpoints); //bottom spinner
        //increase team1 score
        btteam1increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                team1score =team1score + Integer.parseInt(sppoints.getSelectedItem().toString());
                tvscore1.setText("Team 1 Score: "+team1score); }});
        //decrease team1 score
        btteam1decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                team1score =team1score - Integer.parseInt(sppoints.getSelectedItem().toString());
                tvscore1.setText("Team 1 Score: "+team1score); }});
        //increase team2 score
        btteam2increase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                team2score =team2score + Integer.parseInt(sppoints.getSelectedItem().toString());
                tvscore2.setText("Team 2 Score: "+team2score); }});
        //decrease team1 score
        btteam2decrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                team2score =team2score - Integer.parseInt(sppoints.getSelectedItem().toString());
                tvscore2.setText("Team 2 Score: "+team2score); }});
    }
}
